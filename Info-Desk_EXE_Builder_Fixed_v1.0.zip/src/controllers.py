"""
컨트롤러 - 비즈니스 로직 및 데이터 흐름 제어
"""

from typing import List
from .models import Participant, DataManager
from .utils import ConfigManager


class MainController:
    """메인 컨트롤러 클래스"""
    
    def __init__(self):
        self.data_manager = DataManager()
        self.config_manager = ConfigManager()
    
    def add_participant(self, participant: Participant) -> None:
        """참가자 추가"""
        self.data_manager.add_participant(participant)
    
    def get_participants(self) -> List[Participant]:
        """모든 참가자 목록 반환"""
        return self.data_manager.get_participants()
    
    def clear_all_data(self) -> None:
        """모든 데이터 삭제"""
        self.data_manager.clear_all_data()
    
    def get_organizations(self) -> List[str]:
        """소속사 목록 반환"""
        return self.config_manager.load_organizations()
    
    def save_organizations(self, organizations: List[str]) -> None:
        """소속사 목록 저장"""
        self.config_manager.save_organizations(organizations)
    
    def get_notice_text(self) -> str:
        """안내문구 반환"""
        return self.config_manager.load_notice()
    
    def save_notice_text(self, notice_text: str) -> None:
        """안내문구 저장"""
        self.config_manager.save_notice(notice_text)