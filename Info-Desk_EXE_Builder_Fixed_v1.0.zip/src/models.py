"""
데이터 모델 및 저장/로드 로직
"""

import json
import os
from datetime import datetime
from typing import List, Dict, Optional


class Participant:
    """참가자 정보 모델"""
    
    def __init__(self, organization: str, name: str, user_id: str, phone: str, 
                 participant_id: Optional[int] = None, timestamp: Optional[str] = None):
        self.id = participant_id
        self.organization = organization
        self.name = name
        self.user_id = user_id
        self.phone = phone
        self.timestamp = timestamp or datetime.now().isoformat()
    
    def to_dict(self) -> Dict:
        """참가자 정보를 딕셔너리로 변환"""
        return {
            "id": self.id,
            "organization": self.organization,
            "name": self.name,
            "user_id": self.user_id,
            "phone": self.phone,
            "timestamp": self.timestamp
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'Participant':
        """딕셔너리에서 참가자 객체 생성"""
        return cls(
            organization=data["organization"],
            name=data["name"],
            user_id=data["user_id"],
            phone=data["phone"],
            participant_id=data.get("id"),
            timestamp=data.get("timestamp")
        )
    
    def get_masked_id(self) -> str:
        """마스킹된 ID 반환"""
        if len(self.user_id) >= 3:
            return self.user_id[:3] + "***-*******"
        return "***-*******"
    
    def get_masked_phone(self) -> str:
        """마스킹된 전화번호 반환"""
        return "010-****-****"


class DataManager:
    """데이터 저장 및 관리 클래스"""
    
    def __init__(self, data_file: str = "data/participants.json"):
        self.data_file = data_file
        self.participants: List[Participant] = []
        self._next_id = 1
        self._ensure_data_directory()
        self.load_data()
    
    def _ensure_data_directory(self):
        """데이터 디렉토리 생성"""
        os.makedirs(os.path.dirname(self.data_file), exist_ok=True)
    
    def add_participant(self, participant: Participant) -> None:
        """참가자 추가"""
        participant.id = self._next_id
        self.participants.append(participant)
        self._next_id += 1
        self.save_data()
    
    def get_participants(self) -> List[Participant]:
        """모든 참가자 목록 반환"""
        return self.participants.copy()
    
    def clear_all_data(self) -> None:
        """모든 데이터 삭제"""
        self.participants.clear()
        self._next_id = 1
        self.save_data()
    
    def save_data(self) -> None:
        """데이터를 JSON 파일에 저장"""
        data = {
            "participants": [p.to_dict() for p in self.participants]
        }
        
        with open(self.data_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    def load_data(self) -> None:
        """JSON 파일에서 데이터 로드"""
        try:
            if os.path.exists(self.data_file):
                with open(self.data_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                self.participants = [
                    Participant.from_dict(p_data) 
                    for p_data in data.get("participants", [])
                ]
                
                # 다음 ID 계산
                if self.participants:
                    max_id = max(p.id for p in self.participants if p.id)
                    self._next_id = max_id + 1
            else:
                # 파일이 없으면 빈 파일 생성
                self.save_data()
                
        except (json.JSONDecodeError, FileNotFoundError, KeyError) as e:
            print(f"데이터 로드 오류: {e}")
            self.participants = []
            self._next_id = 1