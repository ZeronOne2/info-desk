"""
유틸리티 함수들
"""

import json
import os
from datetime import datetime
from typing import List, Optional
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment


class ConfigManager:
    """설정 파일 관리 클래스"""
    
    @staticmethod
    def load_organizations(config_file: str = "config/organizations.json") -> List[str]:
        """소속사 목록 로드"""
        try:
            if os.path.exists(config_file):
                with open(config_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                return data.get("organizations", [])
        except (json.JSONDecodeError, FileNotFoundError) as e:
            print(f"소속사 목록 로드 오류: {e}")
        
        # 기본 소속사 목록 반환
        return ["회사A", "회사B", "회사C", "개인"]
    
    @staticmethod
    def save_organizations(organizations: List[str], config_file: str = "config/organizations.json") -> None:
        """소속사 목록 저장"""
        os.makedirs(os.path.dirname(config_file), exist_ok=True)
        
        data = {"organizations": organizations}
        with open(config_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    @staticmethod
    def load_notice(notice_file: str = "config/notice.txt") -> str:
        """안내문구 로드"""
        try:
            if os.path.exists(notice_file):
                with open(notice_file, 'r', encoding='utf-8') as f:
                    return f.read()
        except FileNotFoundError as e:
            print(f"안내문구 로드 오류: {e}")
        
        # 기본 안내문구 반환
        return "행사에 오신 것을 환영합니다.\n\n참가자 정보를 정확히 입력해 주세요."
    
    @staticmethod
    def save_notice(notice_text: str, notice_file: str = "config/notice.txt") -> None:
        """안내문구 저장"""
        os.makedirs(os.path.dirname(notice_file), exist_ok=True)
        
        with open(notice_file, 'w', encoding='utf-8') as f:
            f.write(notice_text)


class ExcelExporter:
    """엑셀 내보내기 클래스"""
    
    @staticmethod
    def export_participants(participants: List, output_dir: str = ".", filename: Optional[str] = None) -> str:
        """
        참가자 목록을 엑셀 파일로 내보내기
        Args:
            participants: 참가자 목록
            output_dir: 출력 디렉토리
            filename: 파일명 (None이면 자동 생성)
        Returns:
            생성된 파일 경로
        """
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"participants_{timestamp}.xlsx"
        
        filepath = os.path.join(output_dir, filename)
        
        # 워크북 생성
        wb = Workbook()
        ws = wb.active
        ws.title = "참가자 목록"
        
        # 헤더 설정
        headers = ["번호", "소속사", "이름", "ID", "전화번호", "입력시각"]
        
        # 헤더 스타일
        header_font = Font(bold=True, color="FFFFFF")
        header_fill = PatternFill(start_color="2E5090", end_color="2E5090", fill_type="solid")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        # 헤더 작성
        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = header_alignment
        
        # 데이터 작성
        for row, participant in enumerate(participants, 2):
            ws.cell(row=row, column=1, value=participant.id)
            ws.cell(row=row, column=2, value=participant.organization)
            ws.cell(row=row, column=3, value=participant.name)
            ws.cell(row=row, column=4, value=participant.user_id)
            ws.cell(row=row, column=5, value=participant.phone)
            
            # 타임스탬프 포맷팅
            try:
                dt = datetime.fromisoformat(participant.timestamp)
                formatted_time = dt.strftime("%Y-%m-%d %H:%M:%S")
            except:
                formatted_time = participant.timestamp
            
            ws.cell(row=row, column=6, value=formatted_time)
        
        # 컬럼 너비 자동 조정
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            
            for cell in column:
                if cell.value:
                    max_length = max(max_length, len(str(cell.value)))
            
            # 최소 너비 10, 최대 너비 50
            adjusted_width = min(max(max_length + 2, 10), 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        # 파일 저장
        wb.save(filepath)
        return filepath


def format_datetime(dt_string: str) -> str:
    """ISO 형식 날짜를 읽기 쉬운 형식으로 변환"""
    try:
        dt = datetime.fromisoformat(dt_string)
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except:
        return dt_string