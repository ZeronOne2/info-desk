"""
메인 윈도우 UI 구성
"""

import os
from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QLineEdit, QComboBox, QTextEdit, QPushButton, QTableWidget,
    QTableWidgetItem, QMessageBox, QFileDialog, QSizePolicy, QFrame
)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QFont, QPalette

from .models import Participant, DataManager
from .validators import Validator
from .utils import ConfigManager, ExcelExporter
from .controllers import MainController


class MainWindow(QMainWindow):
    """메인 윈도우 클래스"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Info-Desk - 행사 참가자 정보 관리")
        self.setGeometry(100, 100, 1000, 800)
        
        # 컨트롤러 초기화
        self.controller = MainController()
        
        # UI 초기화
        self.init_ui()
        
        # 데이터 로드
        self.load_initial_data()
    
    def init_ui(self):
        """UI 구성 요소 초기화"""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # 메인 레이아웃
        main_layout = QVBoxLayout(central_widget)
        main_layout.setSpacing(15)
        main_layout.setContentsMargins(20, 20, 20, 20)
        
        # 안내문구 영역
        self.create_notice_section(main_layout)
        
        # 입력 폼 영역
        self.create_input_section(main_layout)
        
        # 제어 버튼 영역
        self.create_control_section(main_layout)
        
        # 참가자 리스트 영역
        self.create_table_section(main_layout)
        
        # 위험 작업 버튼 영역
        self.create_danger_section(main_layout)
        
        # 스타일 적용
        self.apply_styles()
    
    def create_notice_section(self, parent_layout):
        """안내문구 섹션 생성"""
        notice_frame = QFrame()
        notice_frame.setFrameStyle(QFrame.StyledPanel)
        notice_layout = QVBoxLayout(notice_frame)
        
        # 안내문구 헤더
        header_layout = QHBoxLayout()
        notice_label = QLabel("행사 안내")
        notice_label.setFont(QFont("맑은 고딕", 12, QFont.Bold))
        header_layout.addWidget(notice_label)
        
        header_layout.addStretch()
        
        # 잠금 토글 버튼
        self.lock_button = QPushButton("🔒")
        self.lock_button.setFixedSize(30, 30)
        self.lock_button.clicked.connect(self.toggle_notice_lock)
        header_layout.addWidget(self.lock_button)
        
        notice_layout.addLayout(header_layout)
        
        # 안내문구 텍스트 영역
        self.notice_text = QTextEdit()
        self.notice_text.setMaximumHeight(100)
        self.notice_text.setReadOnly(True)
        self.notice_text.textChanged.connect(self.save_notice)
        notice_layout.addWidget(self.notice_text)
        
        parent_layout.addWidget(notice_frame)
    
    def create_input_section(self, parent_layout):
        """입력 폼 섹션 생성"""
        input_frame = QFrame()
        input_frame.setFrameStyle(QFrame.StyledPanel)
        input_layout = QVBoxLayout(input_frame)
        
        # 섹션 제목
        title_label = QLabel("행사 참가자 정보 등록")
        title_label.setFont(QFont("맑은 고딕", 14, QFont.Bold))
        title_label.setAlignment(Qt.AlignCenter)
        input_layout.addWidget(title_label)
        
        # 입력 필드 그리드
        grid_layout = QGridLayout()
        grid_layout.setHorizontalSpacing(20)
        grid_layout.setVerticalSpacing(15)
        
        # 소속사
        grid_layout.addWidget(QLabel("소속사:"), 0, 0)
        self.organization_combo = QComboBox()
        self.organization_combo.setMinimumWidth(200)
        grid_layout.addWidget(self.organization_combo, 0, 1)
        
        # 이름
        grid_layout.addWidget(QLabel("이름:"), 1, 0)
        self.name_edit = QLineEdit()
        self.name_edit.setMinimumWidth(200)
        grid_layout.addWidget(self.name_edit, 1, 1)
        
        # ID
        grid_layout.addWidget(QLabel("ID:"), 0, 2)
        self.id_edit = QLineEdit()
        self.id_edit.setPlaceholderText("000000-0000000")
        self.id_edit.setMinimumWidth(200)
        grid_layout.addWidget(self.id_edit, 0, 3)
        
        # 전화번호
        grid_layout.addWidget(QLabel("전화번호:"), 1, 2)
        self.phone_edit = QLineEdit()
        self.phone_edit.setPlaceholderText("010-0000-0000")
        self.phone_edit.setMinimumWidth(200)
        grid_layout.addWidget(self.phone_edit, 1, 3)
        
        input_layout.addLayout(grid_layout)
        
        # 버튼 영역
        button_layout = QHBoxLayout()
        button_layout.addStretch()
        
        self.save_button = QPushButton("저장")
        self.save_button.setMinimumSize(100, 35)
        self.save_button.clicked.connect(self.save_participant)
        button_layout.addWidget(self.save_button)
        
        self.clear_button = QPushButton("초기화")
        self.clear_button.setMinimumSize(100, 35)
        self.clear_button.clicked.connect(self.clear_form)
        button_layout.addWidget(self.clear_button)
        
        input_layout.addLayout(button_layout)
        parent_layout.addWidget(input_frame)
    
    def create_control_section(self, parent_layout):
        """제어 버튼 섹션 생성"""
        control_layout = QHBoxLayout()
        
        self.toggle_list_button = QPushButton("참가자 목록 숨기기")
        self.toggle_list_button.setMinimumSize(150, 35)
        self.toggle_list_button.clicked.connect(self.toggle_participant_list)
        control_layout.addWidget(self.toggle_list_button)
        
        control_layout.addStretch()
        
        self.export_button = QPushButton("엑셀 내보내기")
        self.export_button.setMinimumSize(120, 35)
        self.export_button.clicked.connect(self.export_to_excel)
        control_layout.addWidget(self.export_button)
        
        parent_layout.addLayout(control_layout)
    
    def create_table_section(self, parent_layout):
        """참가자 리스트 테이블 섹션 생성"""
        self.table = QTableWidget()
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["소속사", "이름", "ID", "전화번호"])
        
        # 테이블 설정
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.horizontalHeader().setStretchLastSection(True)
        
        # 컬럼 너비 설정
        self.table.setColumnWidth(0, 150)  # 소속사
        self.table.setColumnWidth(1, 120)  # 이름
        self.table.setColumnWidth(2, 180)  # ID
        self.table.setColumnWidth(3, 150)  # 전화번호
        
        parent_layout.addWidget(self.table)
    
    def create_danger_section(self, parent_layout):
        """위험 작업 버튼 섹션 생성"""
        # 구분선
        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setFrameShadow(QFrame.Sunken)
        parent_layout.addWidget(line)
        
        # 여백
        parent_layout.addSpacing(20)
        
        danger_layout = QHBoxLayout()
        danger_layout.addStretch()
        
        self.delete_all_button = QPushButton("⚠️ 데이터 전체 삭제")
        self.delete_all_button.setMinimumSize(200, 40)
        self.delete_all_button.clicked.connect(self.delete_all_data)
        danger_layout.addWidget(self.delete_all_button)
        
        danger_layout.addStretch()
        parent_layout.addLayout(danger_layout)
    
    def apply_styles(self):
        """스타일 적용"""
        # 메인 색상 설정
        self.setStyleSheet("""
            QMainWindow {
                background-color: #f5f5f5;
            }
            
            QFrame {
                background-color: white;
                border-radius: 5px;
                padding: 10px;
            }
            
            QLabel {
                color: #2E5090;
                font-weight: bold;
            }
            
            QLineEdit, QComboBox, QTextEdit {
                border: 2px solid #ddd;
                border-radius: 5px;
                padding: 5px;
                font-size: 10pt;
            }
            
            QLineEdit:focus, QComboBox:focus, QTextEdit:focus {
                border-color: #2E5090;
            }
            
            QPushButton {
                background-color: #2E5090;
                color: white;
                border: none;
                border-radius: 5px;
                font-weight: bold;
                font-size: 9pt;
            }
            
            QPushButton:hover {
                background-color: #1e3a70;
            }
            
            QPushButton:pressed {
                background-color: #0f1f40;
            }
            
            QTableWidget {
                gridline-color: #ddd;
                background-color: white;
                alternate-background-color: #f8f9fa;
            }
            
            QTableWidget::item {
                padding: 8px;
            }
            
            QHeaderView::section {
                background-color: #2E5090;
                color: white;
                font-weight: bold;
                border: none;
                padding: 8px;
            }
        """)
        
        # 위험 버튼 별도 스타일
        self.delete_all_button.setStyleSheet("""
            QPushButton {
                background-color: #FF6B6B;
                color: white;
            }
            
            QPushButton:hover {
                background-color: #ff5252;
            }
            
            QPushButton:pressed {
                background-color: #d32f2f;
            }
        """)
    
    def load_initial_data(self):
        """초기 데이터 로드"""
        # 소속사 목록 로드
        organizations = self.controller.get_organizations()
        self.organization_combo.addItems(organizations)
        
        # 안내문구 로드
        notice_text = self.controller.get_notice_text()
        self.notice_text.setPlainText(notice_text)
        
        # 참가자 목록 로드
        self.refresh_table()
    
    def toggle_notice_lock(self):
        """안내문구 잠금/해제 토글"""
        if self.notice_text.isReadOnly():
            self.notice_text.setReadOnly(False)
            self.lock_button.setText("🔓")
        else:
            self.notice_text.setReadOnly(True)
            self.lock_button.setText("🔒")
    
    def save_notice(self):
        """안내문구 저장"""
        if not self.notice_text.isReadOnly():
            self.controller.save_notice_text(self.notice_text.toPlainText())
    
    def save_participant(self):
        """참가자 정보 저장"""
        # 입력값 수집
        organization = self.organization_combo.currentText()
        name = self.name_edit.text().strip()
        user_id = self.id_edit.text().strip()
        phone = self.phone_edit.text().strip()
        
        # 유효성 검증
        valid, error_msg = Validator.validate_all(organization, name, user_id, phone)
        
        if not valid:
            QMessageBox.warning(self, "입력 오류", error_msg)
            return
        
        # 참가자 저장
        try:
            participant = Participant(organization, name, user_id, phone)
            self.controller.add_participant(participant)
            
            # 폼 초기화
            self.clear_form()
            
            # 테이블 새로고침
            self.refresh_table()
            
            # 성공 메시지
            QMessageBox.information(self, "저장 완료", "참가자 정보가 저장되었습니다.")
            
        except Exception as e:
            QMessageBox.critical(self, "저장 오류", f"저장 중 오류가 발생했습니다: {str(e)}")
    
    def clear_form(self):
        """입력 폼 초기화"""
        self.organization_combo.setCurrentIndex(0)
        self.name_edit.clear()
        self.id_edit.clear()
        self.phone_edit.clear()
        self.name_edit.setFocus()
    
    def refresh_table(self):
        """참가자 테이블 새로고침"""
        participants = self.controller.get_participants()
        
        self.table.setRowCount(len(participants))
        
        for row, participant in enumerate(participants):
            self.table.setItem(row, 0, QTableWidgetItem(participant.organization))
            self.table.setItem(row, 1, QTableWidgetItem(participant.name))
            self.table.setItem(row, 2, QTableWidgetItem(participant.get_masked_id()))
            self.table.setItem(row, 3, QTableWidgetItem(participant.get_masked_phone()))
    
    def toggle_participant_list(self):
        """참가자 목록 표시/숨김 토글"""
        if self.table.isVisible():
            self.table.hide()
            self.toggle_list_button.setText("참가자 목록 보기")
        else:
            self.table.show()
            self.toggle_list_button.setText("참가자 목록 숨기기")
    
    def export_to_excel(self):
        """엑셀 파일로 내보내기"""
        try:
            # 파일 저장 대화상자
            filename, _ = QFileDialog.getSaveFileName(
                self, 
                "엑셀 파일 저장", 
                "participants.xlsx",
                "Excel Files (*.xlsx)"
            )
            
            if filename:
                participants = self.controller.get_participants()
                
                if not participants:
                    QMessageBox.information(self, "알림", "내보낼 데이터가 없습니다.")
                    return
                
                # 엑셀 내보내기
                output_dir = os.path.dirname(filename)
                file_name = os.path.basename(filename)
                
                exported_file = ExcelExporter.export_participants(
                    participants, output_dir, file_name
                )
                
                QMessageBox.information(
                    self, 
                    "내보내기 완료", 
                    f"파일이 저장되었습니다:\n{exported_file}"
                )
                
        except Exception as e:
            QMessageBox.critical(self, "내보내기 오류", f"내보내기 중 오류가 발생했습니다: {str(e)}")
    
    def delete_all_data(self):
        """모든 데이터 삭제 (경고 팝업 포함)"""
        # 경고 메시지 박스 생성
        msg_box = QMessageBox()
        msg_box.setIcon(QMessageBox.Warning)
        msg_box.setWindowTitle("⚠️ 경고")
        msg_box.setText(
            "모든 참가자 데이터가 영구적으로 삭제됩니다.\n\n"
            "이 작업은 되돌릴 수 없으며 백업되지 않습니다.\n\n"
            "정말 삭제하시겠습니까?"
        )
        
        # 버튼 설정
        msg_box.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        msg_box.setDefaultButton(QMessageBox.No)  # 취소 버튼 기본
        
        button_yes = msg_box.button(QMessageBox.Yes)
        button_yes.setText("삭제")
        
        button_no = msg_box.button(QMessageBox.No)
        button_no.setText("취소")
        
        # 사용자 응답 처리
        reply = msg_box.exec_()
        
        if reply == QMessageBox.Yes:
            try:
                # 데이터 삭제
                self.controller.clear_all_data()
                
                # 테이블 초기화
                self.refresh_table()
                
                # 완료 메시지
                QMessageBox.information(self, "완료", "모든 데이터가 삭제되었습니다.")
                
            except Exception as e:
                QMessageBox.critical(self, "삭제 오류", f"삭제 중 오류가 발생했습니다: {str(e)}")