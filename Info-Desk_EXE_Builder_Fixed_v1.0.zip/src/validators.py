"""
입력 데이터 유효성 검증 모듈
"""

import re
from typing import Tuple


class Validator:
    """데이터 검증 클래스"""
    
    # 정규표현식 패턴
    USER_ID_PATTERN = r'^\d{6}-\d{7}$'
    PHONE_PATTERN = r'^010-\d{4}-\d{4}$'
    
    @staticmethod
    def validate_user_id(user_id: str) -> Tuple[bool, str]:
        """
        ID 형식 검증
        Args:
            user_id: 검증할 ID 문자열
        Returns:
            (유효성, 오류메시지) 튜플
        """
        if not user_id.strip():
            return False, "ID를 입력해주세요."
        
        if not re.match(Validator.USER_ID_PATTERN, user_id.strip()):
            return False, "ID는 000000-0000000 형식(6자리 숫자-7자리 숫자)이어야 합니다."
        
        return True, ""
    
    @staticmethod
    def validate_phone(phone: str) -> Tuple[bool, str]:
        """
        전화번호 형식 검증
        Args:
            phone: 검증할 전화번호 문자열
        Returns:
            (유효성, 오류메시지) 튜플
        """
        if not phone.strip():
            return False, "전화번호를 입력해주세요."
        
        if not re.match(Validator.PHONE_PATTERN, phone.strip()):
            return False, "전화번호는 010-XXXX-XXXX 형식이어야 합니다."
        
        return True, ""
    
    @staticmethod
    def validate_name(name: str) -> Tuple[bool, str]:
        """
        이름 검증 (필수 입력)
        Args:
            name: 검증할 이름 문자열
        Returns:
            (유효성, 오류메시지) 튜플
        """
        if not name.strip():
            return False, "이름은 필수 입력 항목입니다."
        
        return True, ""
    
    @staticmethod
    def validate_organization(organization: str) -> Tuple[bool, str]:
        """
        소속 검증
        Args:
            organization: 검증할 소속 문자열
        Returns:
            (유효성, 오류메시지) 튜플
        """
        if not organization.strip():
            return False, "소속을 선택해주세요."
        
        return True, ""
    
    @classmethod
    def validate_all(cls, organization: str, name: str, user_id: str, phone: str) -> Tuple[bool, str]:
        """
        모든 필드 검증
        Args:
            organization: 소속
            name: 이름
            user_id: ID
            phone: 전화번호
        Returns:
            (유효성, 오류메시지) 튜플
        """
        # 소속 검증
        valid, error_msg = cls.validate_organization(organization)
        if not valid:
            return False, error_msg
        
        # 이름 검증
        valid, error_msg = cls.validate_name(name)
        if not valid:
            return False, error_msg
        
        # ID 검증
        valid, error_msg = cls.validate_user_id(user_id)
        if not valid:
            return False, error_msg
        
        # 전화번호 검증
        valid, error_msg = cls.validate_phone(phone)
        if not valid:
            return False, error_msg
        
        return True, ""