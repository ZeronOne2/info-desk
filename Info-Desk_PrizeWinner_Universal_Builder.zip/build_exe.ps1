# Info-Desk Prize Winner System Universal Builder (PowerShell)
Set-Location $PSScriptRoot

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Info-Desk Prize Winner System Builder" -ForegroundColor Green
Write-Host "Universal Python Version Support" -ForegroundColor Yellow
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Check Python and version
try {
    $pythonVersion = python --version 2>$null
    Write-Host "Python found: $pythonVersion" -ForegroundColor Green
    
    # Extract version number
    $versionMatch = [regex]::Match($pythonVersion, "Python (\d+)\.(\d+)")
    if ($versionMatch.Success) {
        $majorVersion = [int]$versionMatch.Groups[1].Value
        $minorVersion = [int]$versionMatch.Groups[2].Value
        Write-Host "Detected Python $majorVersion.$minorVersion" -ForegroundColor Gray
    }
} catch {
    Write-Host "[ERROR] Python is not installed." -ForegroundColor Red
    Write-Host "Please install Python 3.8+ from python.org" -ForegroundColor Yellow
    Read-Host "Press Enter to exit"
    exit 1
}

# Install packages
Write-Host ""
Write-Host "[1/4] Installing packages based on Python version..." -ForegroundColor Yellow

# Install common packages first
Write-Host "Installing PyQt5 and openpyxl..." -ForegroundColor Gray
pip install "PyQt5>=5.15.0,<5.16.0" "openpyxl>=3.1.0,<4.0.0"

# Install PyInstaller based on version
Write-Host "Installing PyInstaller..." -ForegroundColor Gray
if ($majorVersion -ge 3 -and $minorVersion -ge 11) {
    Write-Host "Python 3.11+ detected - installing PyInstaller 6.x" -ForegroundColor Green
    pip install "pyinstaller>=6.0.0"
} else {
    Write-Host "Python 3.8-3.10 detected - installing PyInstaller 5.x" -ForegroundColor Green
    pip install "pyinstaller>=4.0,<6.0"
}

if ($LASTEXITCODE -ne 0) {
    Write-Host "Primary installation failed. Trying fallback..." -ForegroundColor Yellow
    pip install pyinstaller
    if ($LASTEXITCODE -ne 0) {
        Write-Host "[ERROR] Package installation failed." -ForegroundColor Red
        Write-Host "Manual installation required:" -ForegroundColor Yellow
        Write-Host "pip install PyQt5 openpyxl pyinstaller" -ForegroundColor Yellow
        Read-Host "Press Enter to exit"
        exit 1
    }
}

# Clean previous builds
Write-Host ""
Write-Host "[2/4] Cleaning previous builds..." -ForegroundColor Yellow
Remove-Item -Path "build" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path "dist" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path "*.spec" -Force -ErrorAction SilentlyContinue

# Build EXE
Write-Host ""
Write-Host "[3/4] Building EXE file..." -ForegroundColor Yellow
Write-Host "This may take a few minutes..." -ForegroundColor Gray

$buildArgs = @(
    "--onefile",
    "--windowed",
    "--name=Info-Desk-PrizeWinner",
    "--add-data=config;config",
    "--add-data=data;data",
    "--distpath=dist",
    "--workpath=build",
    "--clean",
    "--noconfirm",
    "main.py"
)

& python -m PyInstaller @buildArgs

if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "[ERROR] Build failed!" -ForegroundColor Red
    Write-Host ""
    Write-Host "Troubleshooting tips:" -ForegroundColor Yellow
    Write-Host "1. Try: pip install --upgrade pip pyinstaller" -ForegroundColor Gray
    Write-Host "2. Check antivirus settings" -ForegroundColor Gray
    Write-Host "3. Make sure all packages are compatible" -ForegroundColor Gray
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host ""
Write-Host "[4/4] Build completed successfully!" -ForegroundColor Green
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "RESULT: dist\Info-Desk-PrizeWinner.exe" -ForegroundColor Green
Write-Host "Size: ~50-60 MB" -ForegroundColor Yellow
Write-Host "Python Version: $pythonVersion" -ForegroundColor Gray
Write-Host "========================================" -ForegroundColor Cyan

Read-Host "`nPress Enter to exit"
