#!/usr/bin/env python3
"""
Info-Desk Prize Winner System Universal Builder (Python)
Python 3.8 - 3.13 호환
"""

import os
import sys
import shutil
import subprocess

def get_python_version():
    """Python 버전 정보 반환"""
    return sys.version_info.major, sys.version_info.minor

def install_packages():
    """Python 버전에 맞는 패키지 설치"""
    major, minor = get_python_version()
    print(f"Python {major}.{minor} detected")
    
    # 공통 패키지 먼저 설치
    common_packages = [
        "PyQt5>=5.15.0,<5.16.0",
        "openpyxl>=3.1.0,<4.0.0"
    ]
    
    print("Installing common packages...")
    for package in common_packages:
        result = subprocess.run([sys.executable, '-m', 'pip', 'install', package])
        if result.returncode != 0:
            print(f"Failed to install {package}")
            return False
    
    # PyInstaller 버전 선택
    print("Installing PyInstaller...")
    if major >= 3 and minor >= 11:
        print("Using PyInstaller 6.x for Python 3.11+")
        pyinstaller_pkg = "pyinstaller>=6.0.0"
    else:
        print("Using PyInstaller 5.x for Python 3.8-3.10")
        pyinstaller_pkg = "pyinstaller>=4.0,<6.0"
    
    result = subprocess.run([sys.executable, '-m', 'pip', 'install', pyinstaller_pkg])
    if result.returncode != 0:
        print("Primary PyInstaller installation failed. Trying fallback...")
        result = subprocess.run([sys.executable, '-m', 'pip', 'install', 'pyinstaller'])
        if result.returncode != 0:
            print("PyInstaller installation failed completely")
            return False
    
    return True

def build_exe():
    print("="*60)
    print("Info-Desk Prize Winner System Universal Builder")
    print("="*60)
    
    # Change to script directory
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    # Show Python version
    major, minor = get_python_version()
    print(f"Python version: {major}.{minor}")
    print()
    
    # Install packages
    print("[1/4] Installing packages based on Python version...")
    if not install_packages():
        print("\n[ERROR] Package installation failed.")
        print("\nTroubleshooting:")
        print("1. Try: pip install --upgrade pip")
        print("2. Try manual: pip install PyQt5 openpyxl pyinstaller")
        print("3. Check internet connection")
        return False
    
    # Clean previous builds
    print("\n[2/4] Cleaning previous builds...")
    for path in ['build', 'dist']:
        if os.path.exists(path):
            shutil.rmtree(path)
    
    for spec_file in [f for f in os.listdir('.') if f.endswith('.spec')]:
        os.remove(spec_file)
    
    # Build EXE
    print("\n[3/4] Building EXE file...")
    print("This may take a few minutes...")
    
    cmd = [
        sys.executable, '-m', 'PyInstaller',
        '--onefile',
        '--windowed', 
        '--name=Info-Desk-PrizeWinner',
        '--add-data=config;config',
        '--add-data=data;data',
        '--distpath=dist',
        '--workpath=build',
        '--clean',
        '--noconfirm',
        'main.py'
    ]
    
    result = subprocess.run(cmd)
    if result.returncode != 0:
        print("\n[ERROR] Build failed!")
        print("\nTroubleshooting:")
        print("1. Try: pip install --upgrade pyinstaller")
        print("2. Check antivirus settings")
        print("3. Make sure all packages are compatible")
        return False
    
    print("\n[4/4] Build completed successfully!")
    print("\n" + "="*60)
    print("RESULT: dist/Info-Desk-PrizeWinner.exe")
    print("Size: ~50-60 MB")
    print(f"Built with Python {major}.{minor}")
    print("="*60)
    
    return True

if __name__ == "__main__":
    success = build_exe()
    input("\nPress Enter to exit...")
    sys.exit(0 if success else 1)
