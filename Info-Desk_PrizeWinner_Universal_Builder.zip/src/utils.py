"""
유틸리티 함수들
"""

import json
import os
import sys
from datetime import datetime
from typing import List, Optional
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment


def get_resource_path(relative_path):
    """PyInstaller로 빌드된 실행 파일에서 리소스 경로를 올바르게 찾는 함수"""
    try:
        # PyInstaller로 빌드된 경우 _MEIPASS 사용
        base_path = sys._MEIPASS
    except AttributeError:
        # 개발 환경에서는 현재 디렉토리 사용
        base_path = os.path.abspath(".")
    
    return os.path.join(base_path, relative_path)


class ConfigManager:
    """설정 파일 관리 클래스"""
    
    @staticmethod
    def load_departments(config_file: str = "config/departments.json") -> List[str]:
        """소속사 목록 로드"""
        try:
            # PyInstaller 호환 경로 사용
            file_path = get_resource_path(config_file)
            if os.path.exists(file_path):
                with open(file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                return data.get("departments", [])
        except (json.JSONDecodeError, FileNotFoundError) as e:
            print(f"소속사 목록 로드 오류: {e}")
        # 기본 소속사 목록 반환
        return ["영업부", "마케팅부", "개발부", "인사부", "총무부", "기획부", "재무부", "품질관리부", "생산부", "고객서비스부"]
    
    @staticmethod
    def load_workplaces(config_file: str = "config/workplaces.json") -> List[str]:
        """근무지 목록 로드"""
        try:
            # PyInstaller 호환 경로 사용
            file_path = get_resource_path(config_file)
            if os.path.exists(file_path):
                with open(file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                return data.get("workplaces", [])
        except (json.JSONDecodeError, FileNotFoundError) as e:
            print(f"근무지 목록 로드 오류: {e}")
        # 기본 근무지 목록 반환
        return ["본사", "서울지점", "부산지점", "대구지점", "대전지점", "광주지점", "인천지점", "울산지점", "수원지점", "창원지점", "그외(직접입력)"]
    
    @staticmethod
    def load_prizes(config_file: str = "config/prizes.json") -> List[str]:
        """경품내역 목록 로드"""
        try:
            # PyInstaller 호환 경로 사용
            file_path = get_resource_path(config_file)
            if os.path.exists(file_path):
                with open(file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                return data.get("prizes", [])
        except (json.JSONDecodeError, FileNotFoundError) as e:
            print(f"경품내역 목록 로드 오류: {e}")
        # 기본 경품내역 목록 반환
        return ["1등상 - 스마트폰", "2등상 - 태블릿", "3등상 - 무선이어폰", "4등상 - 커피머신", "5등상 - 상품권 10만원", "참가상 - 상품권 5만원", "특별상 - 노트북", "우수상 - 스마트워치", "장려상 - 백화점상품권", "감사상 - 치킨상품권"]


class ExcelExporter:
    """엑셀 내보내기 클래스"""
    
    @staticmethod
    def export_winners(winners: List, output_dir: str = ".", filename: Optional[str] = None) -> str:
        """
        경품수여자 목록을 엑셀 파일로 내보내기
        Args:
            winners: 경품수여자 목록
            output_dir: 출력 디렉토리
            filename: 파일명 (None이면 자동 생성)
        Returns:
            생성된 파일 경로
        """
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"prize_winners_{timestamp}.xlsx"
        
        filepath = os.path.join(output_dir, filename)
        
        # 워크북 생성
        wb = Workbook()
        ws = wb.active
        ws.title = "경품수여자 목록"
        
        # 헤더 설정
        headers = ["번호", "소속사", "근무지", "이름", "주민번호", "경품내역", "입력시각"]
        
        # 헤더 스타일
        header_font = Font(bold=True, color="FFFFFF")
        header_fill = PatternFill(start_color="2E5090", end_color="2E5090", fill_type="solid")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        # 헤더 작성
        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = header_alignment
        
        # 데이터 작성
        for row, winner in enumerate(winners, 2):
            ws.cell(row=row, column=1, value=winner.id)
            ws.cell(row=row, column=2, value=winner.department)
            ws.cell(row=row, column=3, value=winner.workplace)
            ws.cell(row=row, column=4, value=winner.name)
            ws.cell(row=row, column=5, value=winner.resident_id)
            ws.cell(row=row, column=6, value=winner.prize)
            
            # 타임스탬프 포맷팅
            try:
                dt = datetime.fromisoformat(winner.timestamp)
                formatted_time = dt.strftime("%Y-%m-%d %H:%M:%S")
            except:
                formatted_time = winner.timestamp
            
            ws.cell(row=row, column=7, value=formatted_time)
        
        # 컬럼 너비 자동 조정
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            
            for cell in column:
                if cell.value:
                    max_length = max(max_length, len(str(cell.value)))
            
            # 최소 너비 10, 최대 너비 50
            adjusted_width = min(max(max_length + 2, 10), 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        # 파일 저장
        wb.save(filepath)
        return filepath


def format_datetime(dt_string: str) -> str:
    """ISO 형식 날짜를 읽기 쉬운 형식으로 변환"""
    try:
        dt = datetime.fromisoformat(dt_string)
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except:
        return dt_string