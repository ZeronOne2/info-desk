"""
컨트롤러 - 비즈니스 로직 및 데이터 흐름 제어
"""

from typing import List
from .models import PrizeWinner, DataManager
from .utils import ConfigManager


class MainController:
    """메인 컨트롤러 클래스"""
    
    def __init__(self):
        self.data_manager = DataManager()
        self.config_manager = ConfigManager()
    
    def add_winner(self, winner: PrizeWinner) -> None:
        """경품수여자 추가"""
        self.data_manager.add_winner(winner)
    
    def get_winners(self) -> List[PrizeWinner]:
        """모든 경품수여자 목록 반환"""
        return self.data_manager.get_winners()
    
    def clear_all_data(self) -> None:
        """모든 데이터 삭제"""
        self.data_manager.clear_all_data()
    
    def get_departments(self) -> List[str]:
        """소속사 목록 반환"""
        return self.config_manager.load_departments()
    
    def get_workplaces(self) -> List[str]:
        """근무지 목록 반환"""
        return self.config_manager.load_workplaces()
    
    def get_prizes(self) -> List[str]:
        """경품내역 목록 반환"""
        return self.config_manager.load_prizes()