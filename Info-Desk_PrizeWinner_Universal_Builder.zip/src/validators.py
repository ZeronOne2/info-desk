"""
입력 데이터 유효성 검증 모듈
"""

import re
from typing import Tuple


class Validator:
    """데이터 검증 클래스"""
    
    # 정규표현식 패턴
    RESIDENT_ID_PATTERN = r'^\d{6}-\d{7}$'
    
    @staticmethod
    def validate_resident_id(resident_id: str) -> Tuple[bool, str]:
        """
        주민번호 형식 검증
        Args:
            resident_id: 검증할 주민번호 문자열
        Returns:
            (유효성, 오류메시지) 튜플
        """
        if not resident_id.strip():
            return False, "주민번호를 입력해주세요."
        
        if not re.match(Validator.RESIDENT_ID_PATTERN, resident_id.strip()):
            return False, "주민번호는 000000-0000000 형식(6자리 숫자-7자리 숫자)이어야 합니다."
        
        return True, ""
    
    @staticmethod
    def validate_name(name: str) -> Tuple[bool, str]:
        """
        이름 검증 (필수 입력)
        Args:
            name: 검증할 이름 문자열
        Returns:
            (유효성, 오류메시지) 튜플
        """
        if not name.strip():
            return False, "이름은 필수 입력 항목입니다."
        
        return True, ""
    
    @staticmethod
    def validate_department(department: str) -> Tuple[bool, str]:
        """
        소속사 검증
        Args:
            department: 검증할 소속사 문자열
        Returns:
            (유효성, 오류메시지) 튜플
        """
        if not department.strip():
            return False, "소속사를 선택해주세요."
        
        return True, ""
    
    @staticmethod
    def validate_workplace(workplace: str) -> Tuple[bool, str]:
        """
        근무지 검증
        Args:
            workplace: 검증할 근무지 문자열
        Returns:
            (유효성, 오류메시지) 튜플
        """
        if not workplace.strip():
            return False, "근무지를 선택하거나 입력해주세요."
        
        return True, ""
    
    @staticmethod
    def validate_prize(prize: str) -> Tuple[bool, str]:
        """
        경품내역 검증
        Args:
            prize: 검증할 경품내역 문자열
        Returns:
            (유효성, 오류메시지) 튜플
        """
        if not prize.strip():
            return False, "경품내역을 선택해주세요."
        
        return True, ""
    
    @classmethod
    def validate_all(cls, department: str, workplace: str, name: str, resident_id: str, prize: str) -> Tuple[bool, str]:
        """
        모든 필드 검증
        Args:
            department: 소속사
            workplace: 근무지
            name: 이름
            resident_id: 주민번호
            prize: 경품내역
        Returns:
            (유효성, 오류메시지) 튜플
        """
        # 소속사 검증
        valid, error_msg = cls.validate_department(department)
        if not valid:
            return False, error_msg
        
        # 근무지 검증
        valid, error_msg = cls.validate_workplace(workplace)
        if not valid:
            return False, error_msg
        
        # 이름 검증
        valid, error_msg = cls.validate_name(name)
        if not valid:
            return False, error_msg
        
        # 주민번호 검증
        valid, error_msg = cls.validate_resident_id(resident_id)
        if not valid:
            return False, error_msg
        
        # 경품내역 검증
        valid, error_msg = cls.validate_prize(prize)
        if not valid:
            return False, error_msg
        
        return True, ""