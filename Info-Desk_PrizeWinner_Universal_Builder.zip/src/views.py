"""
메인 윈도우 UI 구성
"""

import os
from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QLineEdit, QComboBox, QPushButton, QMessageBox, QFileDialog, QFrame
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont

from .models import PrizeWinner, DataManager
from .validators import Validator
from .utils import ConfigManager, ExcelExporter
from .controllers import MainController


class MainWindow(QMainWindow):
    """메인 윈도우 클래스"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Info-Desk - 경품수여자 정보 관리")
        self.setGeometry(100, 100, 800, 400)
        
        # 컨트롤러 초기화
        self.controller = MainController()
        
        # UI 초기화
        self.init_ui()
        
        # 데이터 로드
        self.load_initial_data()
    
    def init_ui(self):
        """UI 구성 요소 초기화"""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # 메인 레이아웃
        main_layout = QVBoxLayout(central_widget)
        main_layout.setSpacing(15)
        main_layout.setContentsMargins(20, 20, 20, 20)
        
        # 입력 폼 영역
        self.create_input_section(main_layout)
        
        # 제어 버튼 영역 (엑셀 내보내기만)
        self.create_control_section(main_layout)
        
        # 스타일 적용
        self.apply_styles()
    
    def create_input_section(self, parent_layout):
        """입력 폼 섹션 생성"""
        input_frame = QFrame()
        input_frame.setFrameStyle(QFrame.StyledPanel)
        input_layout = QVBoxLayout(input_frame)
        
        # 섹션 제목
        title_label = QLabel("경품수여자 정보 등록")
        title_label.setFont(QFont("맑은 고딕", 14, QFont.Bold))
        title_label.setAlignment(Qt.AlignCenter)
        input_layout.addWidget(title_label)
        
        # 입력 필드 그리드
        grid_layout = QGridLayout()
        grid_layout.setHorizontalSpacing(20)
        grid_layout.setVerticalSpacing(15)
        
        # 소속사
        grid_layout.addWidget(QLabel("소속사:"), 0, 0)
        self.department_combo = QComboBox()
        self.department_combo.setMinimumWidth(200)
        grid_layout.addWidget(self.department_combo, 0, 1)
        
        # 근무지
        grid_layout.addWidget(QLabel("근무지:"), 1, 0)
        self.workplace_combo = QComboBox()
        self.workplace_combo.setMinimumWidth(200)
        self.workplace_combo.currentTextChanged.connect(self.on_workplace_changed)
        grid_layout.addWidget(self.workplace_combo, 1, 1)
        
        # 근무지 직접입력 필드 (초기에는 숨김)
        self.workplace_edit = QLineEdit()
        self.workplace_edit.setMinimumWidth(200)
        self.workplace_edit.setPlaceholderText("근무지를 입력하세요")
        self.workplace_edit.hide()
        grid_layout.addWidget(self.workplace_edit, 2, 1)
        
        # 이름
        grid_layout.addWidget(QLabel("이름:"), 0, 2)
        self.name_edit = QLineEdit()
        self.name_edit.setMinimumWidth(200)
        grid_layout.addWidget(self.name_edit, 0, 3)
        
        # 주민번호
        grid_layout.addWidget(QLabel("주민번호:"), 1, 2)
        self.resident_id_edit = QLineEdit()
        self.resident_id_edit.setPlaceholderText("000000-0000000")
        self.resident_id_edit.setMinimumWidth(200)
        grid_layout.addWidget(self.resident_id_edit, 1, 3)
        
        # 경품내역
        grid_layout.addWidget(QLabel("경품내역:"), 2, 2)
        self.prize_combo = QComboBox()
        self.prize_combo.setMinimumWidth(200)
        grid_layout.addWidget(self.prize_combo, 2, 3)
        
        input_layout.addLayout(grid_layout)
        
        # 버튼 영역
        button_layout = QHBoxLayout()
        button_layout.addStretch()
        
        self.save_button = QPushButton("저장")
        self.save_button.setMinimumSize(100, 35)
        self.save_button.clicked.connect(self.save_winner)
        button_layout.addWidget(self.save_button)
        
        self.clear_button = QPushButton("초기화")
        self.clear_button.setMinimumSize(100, 35)
        self.clear_button.clicked.connect(self.clear_form)
        button_layout.addWidget(self.clear_button)
        
        input_layout.addLayout(button_layout)
        parent_layout.addWidget(input_frame)
    
    def create_control_section(self, parent_layout):
        """제어 버튼 섹션 생성"""
        control_layout = QHBoxLayout()
        control_layout.addStretch()
        
        self.export_button = QPushButton("엑셀 내보내기")
        self.export_button.setMinimumSize(120, 35)
        self.export_button.clicked.connect(self.export_to_excel)
        control_layout.addWidget(self.export_button)
        
        parent_layout.addLayout(control_layout)
    
    def apply_styles(self):
        """스타일 적용"""
        self.setStyleSheet("""
            QMainWindow {
                background-color: #f5f5f5;
            }
            
            QFrame {
                background-color: white;
                border-radius: 5px;
                padding: 10px;
            }
            
            QLabel {
                color: #2E5090;
                font-weight: bold;
            }
            
            QLineEdit, QComboBox {
                border: 2px solid #ddd;
                border-radius: 5px;
                padding: 5px;
                font-size: 10pt;
            }
            
            QLineEdit:focus, QComboBox:focus {
                border-color: #2E5090;
            }
            
            QPushButton {
                background-color: #2E5090;
                color: white;
                border: none;
                border-radius: 5px;
                font-weight: bold;
                font-size: 9pt;
            }
            
            QPushButton:hover {
                background-color: #1e3a70;
            }
            
            QPushButton:pressed {
                background-color: #0f1f40;
            }
        """)
    
    def load_initial_data(self):
        """초기 데이터 로드"""
        # 소속 목록 로드
        departments = self.controller.get_departments()
        self.department_combo.addItems(departments)
        
        # 근무지 목록 로드
        workplaces = self.controller.get_workplaces()
        self.workplace_combo.addItems(workplaces)
        
        # 경품내역 목록 로드
        prizes = self.controller.get_prizes()
        self.prize_combo.addItems(prizes)
    
    def on_workplace_changed(self, text):
        """근무지 선택 변경 시 처리"""
        if text == "그외(직접입력)":
            self.workplace_edit.show()
            self.workplace_edit.setFocus()
        else:
            self.workplace_edit.hide()
            self.workplace_edit.clear()
    
    def save_winner(self):
        """경품수여자 정보 저장"""
        # 입력값 수집
        department = self.department_combo.currentText()
        
        # 근무지 처리
        if self.workplace_combo.currentText() == "그외(직접입력)":
            workplace = self.workplace_edit.text().strip()
            if not workplace:
                QMessageBox.warning(self, "입력 오류", "근무지를 입력해주세요.")
                self.workplace_edit.setFocus()
                return
        else:
            workplace = self.workplace_combo.currentText()
        
        name = self.name_edit.text().strip()
        resident_id = self.resident_id_edit.text().strip()
        prize = self.prize_combo.currentText()
        
        # 유효성 검증
        valid, error_msg = Validator.validate_all(department, workplace, name, resident_id, prize)
        
        if not valid:
            QMessageBox.warning(self, "입력 오류", error_msg)
            return
        
        # 경품수여자 저장
        try:
            winner = PrizeWinner(department, workplace, name, resident_id, prize)
            self.controller.add_winner(winner)
            
            # 폼 초기화
            self.clear_form()
            
            # 성공 메시지
            QMessageBox.information(self, "저장 완료", "경품수여자 정보가 저장되었습니다.")
            
        except Exception as e:
            QMessageBox.critical(self, "저장 오류", f"저장 중 오류가 발생했습니다: {str(e)}")
    
    def clear_form(self):
        """입력 폼 초기화"""
        self.department_combo.setCurrentIndex(0)
        self.workplace_combo.setCurrentIndex(0)
        self.workplace_edit.clear()
        self.workplace_edit.hide()
        self.name_edit.clear()
        self.resident_id_edit.clear()
        self.prize_combo.setCurrentIndex(0)
        self.name_edit.setFocus()
    
    def export_to_excel(self):
        """엑셀 파일로 내보내기"""
        try:
            # 파일 저장 대화상자
            filename, _ = QFileDialog.getSaveFileName(
                self, 
                "엑셀 파일 저장", 
                "prize_winners.xlsx",
                "Excel Files (*.xlsx)"
            )
            
            if filename:
                winners = self.controller.get_winners()
                
                if not winners:
                    QMessageBox.information(self, "알림", "내보낼 데이터가 없습니다.")
                    return
                
                # 엑셀 내보내기
                output_dir = os.path.dirname(filename)
                file_name = os.path.basename(filename)
                
                exported_file = ExcelExporter.export_winners(
                    winners, output_dir, file_name
                )
                
                QMessageBox.information(
                    self, 
                    "내보내기 완료", 
                    f"파일이 저장되었습니다:\n{exported_file}"
                )
                
        except Exception as e:
            QMessageBox.critical(self, "내보내기 오류", f"내보내기 중 오류가 발생했습니다: {str(e)}")