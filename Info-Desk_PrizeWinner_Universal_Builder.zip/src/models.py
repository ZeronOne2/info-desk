"""
데이터 모델 및 저장/로드 로직
"""

import json
import os
import sys
from datetime import datetime
from typing import List, Dict, Optional


def get_data_path(relative_path):
    """데이터 파일을 위한 쓰기 가능한 경로를 반환"""
    if getattr(sys, 'frozen', False):
        # PyInstaller로 빌드된 경우 실행 파일과 같은 디렉토리 사용
        base_path = os.path.dirname(sys.executable)
    else:
        # 개발 환경에서는 현재 디렉토리 사용
        base_path = os.path.abspath(".")
    
    return os.path.join(base_path, relative_path)


class PrizeWinner:
    """경품수여자 정보 모델"""
    
    def __init__(self, department: str, workplace: str, name: str, resident_id: str, prize: str,
                 winner_id: Optional[int] = None, timestamp: Optional[str] = None):
        self.id = winner_id
        self.department = department
        self.workplace = workplace
        self.name = name
        self.resident_id = resident_id
        self.prize = prize
        self.timestamp = timestamp or datetime.now().isoformat()
    
    def to_dict(self) -> Dict:
        """경품수여자 정보를 딕셔너리로 변환"""
        return {
            "id": self.id,
            "department": self.department,
            "workplace": self.workplace,
            "name": self.name,
            "resident_id": self.resident_id,
            "prize": self.prize,
            "timestamp": self.timestamp
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'PrizeWinner':
        """딕셔너리에서 경품수여자 객체 생성"""
        return cls(
            department=data["department"],
            workplace=data["workplace"],
            name=data["name"],
            resident_id=data["resident_id"],
            prize=data["prize"],
            winner_id=data.get("id"),
            timestamp=data.get("timestamp")
        )
    
    def get_masked_resident_id(self) -> str:
        """마스킹된 주민번호 반환"""
        if len(self.resident_id) >= 3:
            return self.resident_id[:3] + "***-*******"
        return "***-*******"


class DataManager:
    """데이터 저장 및 관리 클래스"""
    
    def __init__(self, data_file: str = "data/prize_winners.json"):
        # PyInstaller 호환 경로 사용 (쓰기 가능한 위치)
        self.data_file = get_data_path(data_file)
        self.winners: List[PrizeWinner] = []
        self._next_id = 1
        self._ensure_data_directory()
        self.load_data()
    
    def _ensure_data_directory(self):
        """데이터 디렉토리 생성"""
        os.makedirs(os.path.dirname(self.data_file), exist_ok=True)
    
    def add_winner(self, winner: PrizeWinner) -> None:
        """경품수여자 추가"""
        winner.id = self._next_id
        self.winners.append(winner)
        self._next_id += 1
        self.save_data()
    
    def get_winners(self) -> List[PrizeWinner]:
        """모든 경품수여자 목록 반환"""
        return self.winners.copy()
    
    def clear_all_data(self) -> None:
        """모든 데이터 삭제"""
        self.winners.clear()
        self._next_id = 1
        self.save_data()
    
    def save_data(self) -> None:
        """데이터를 JSON 파일에 저장"""
        data = {
            "prize_winners": [w.to_dict() for w in self.winners]
        }
        
        with open(self.data_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    def load_data(self) -> None:
        """JSON 파일에서 데이터 로드"""
        try:
            if os.path.exists(self.data_file):
                with open(self.data_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                self.winners = [
                    PrizeWinner.from_dict(w_data) 
                    for w_data in data.get("prize_winners", [])
                ]
                
                # 다음 ID 계산
                if self.winners:
                    max_id = max(w.id for w in self.winners if w.id)
                    self._next_id = max_id + 1
            else:
                # 파일이 없으면 빈 파일 생성
                self.save_data()
                
        except (json.JSONDecodeError, FileNotFoundError, KeyError) as e:
            print(f"데이터 로드 오류: {e}")
            self.winners = []
            self._next_id = 1