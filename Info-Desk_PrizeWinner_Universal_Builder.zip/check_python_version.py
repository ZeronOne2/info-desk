#!/usr/bin/env python3
"""
Python 버전을 체크하여 적절한 PyInstaller 버전을 결정하는 스크립트
"""
import sys

def main():
    version = sys.version_info
    major, minor = version.major, version.minor
    
    # Python 3.11 이상이면 exit code 0 (새 버전)
    # Python 3.10 이하면 exit code 1 (구 버전)
    if major >= 3 and minor >= 11:
        print(f"Python {major}.{minor} detected - will use PyInstaller 6.x")
        sys.exit(0)
    else:
        print(f"Python {major}.{minor} detected - will use PyInstaller 5.x")
        sys.exit(1)

if __name__ == "__main__":
    main()
